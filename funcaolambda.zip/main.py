Calculo_imposto = lambda fat, taxa : fat * taxa

print(Calculo_imposto(1000,3))